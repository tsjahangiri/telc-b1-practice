/* TELC B1 practice — offline single-page app. Data: window.EXAM_DATA (data/exercises.js). */
(function () {
  "use strict";

  var ALL = (window.EXAM_DATA && window.EXAM_DATA.exercises) || [];
  var STORE_KEY = "telcB1.progress.v1";
  var PREF_KEY = "telcB1.prefs.v1";
  var TYPE_LABEL = {
    lesen1: "Leseverstehen, Teil 1", lesen2: "Leseverstehen, Teil 2", lesen3: "Leseverstehen, Teil 3",
    sprach1: "Sprachbausteine, Teil 1", sprach2: "Sprachbausteine, Teil 2"
  };
  var SHORT = { lesen1: "Lesen 1", lesen2: "Lesen 2", lesen3: "Lesen 3", sprach1: "Sprachb. 1", sprach2: "Sprachb. 2" };

  // ---------- storage (fails gracefully, e.g. private mode) ----------
  function load(key, fallback) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
  }
  function save(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ } }

  var progress = load(STORE_KEY, {});
  var prefs = load(PREF_KEY, { showDupes: false, type: "all", current: null });

  function canon(ex) { return ex.duplicate_of || ex.id; }
  function state(ex) {
    var k = canon(ex);
    if (!progress[k]) progress[k] = { answers: {}, checked: false, revealed: false, score: null, total: null };
    return progress[k];
  }
  function persist() { save(STORE_KEY, progress); }

  // ---------- helpers ----------
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function markIllegible(html) {
    return html.replace(/\[(unleserlich[^\]]*|abgeschnitten|Logo, unleserlich)\]/g, '<span class="illegible" title="Im Original nicht lesbar">[$1]</span>');
  }
  function paragraphs(text) {
    return String(text || "").split("\n").filter(function (l) { return l.trim() !== ""; }).map(function (l) {
      if (l.indexOf("## ") === 0) return "<h3>" + markIllegible(esc(l.slice(3))) + "</h3>";
      return "<p>" + markIllegible(esc(l)) + "</p>";
    }).join("");
  }
  function U(k) { return String(k).toUpperCase(); }
  function nums(ex) { return Object.keys(ex.solution).map(Number).sort(function (a, b) { return a - b; }); }

  // ---------- list / navigation ----------
  function visibleList() {
    return ALL.filter(function (ex) {
      if (!prefs.showDupes && ex.duplicate_of) return false;
      if (prefs.type !== "all" && ex.type !== prefs.type) return false;
      return true;
    });
  }
  var list = visibleList();
  var idx = 0;

  function setIndexById(id) {
    var i = list.findIndex(function (e) { return e.id === id; });
    if (i < 0 && id) {
      // a duplicate id while duplicates are hidden → go to its original
      var ex = ALL.find(function (e) { return e.id === id; });
      if (ex && ex.duplicate_of) i = list.findIndex(function (e) { return e.id === ex.duplicate_of; });
    }
    idx = i < 0 ? 0 : i;
  }

  // ---------- rendering ----------
  var $ = function (id) { return document.getElementById(id); };

  function headerHtml(ex) {
    var title = TYPE_LABEL[ex.type];
    var meta = ['<span>Modelltest ' + esc(ex.paper.slice(1)) + '</span>'];
    if (ex.topic) meta.push("<span>Thema: " + esc(ex.topic) + "</span>");
    meta.push("<span>PDF-Seite " + ex.pages.join(", ") + "</span>");
    var h = '<div class="ex-head"><h1>' + esc(title) + (ex.id.slice(-1) === "b" ? " (Variante)" : "") + "</h1>" +
      '<div class="ex-meta">' + meta.join("") + "</div></div>";
    if (ex.duplicate_of) h += '<div class="dup-notice">Diese Übung ist im PDF identisch mit ' + esc(ex.duplicate_of.replace("-", " · ")) + " — Ihr Fortschritt wird gemeinsam gespeichert.</div>";
    if (ex.uncertain && ex.uncertain.length) {
      h += '<div class="notice"><b>Hinweis:</b> Teile des Originals sind schwer oder nicht lesbar und wurden markiert, nicht ergänzt. ' +
        "<details><summary>Details anzeigen</summary><ul>" + ex.uncertain.map(function (u) {
          return "<li><i>" + esc(u.location) + ":</i> " + esc(u.note) + "</li>"; }).join("") + "</ul></details></div>";
    }
    h += '<div class="instructions">' + esc(ex.instructions) + "</div>";
    return h;
  }

  function scoreHtml(st) {
    if (!st.checked || st.total == null) return "";
    var r = st.score / st.total, cls = r >= 0.8 ? "good" : r >= 0.5 ? "mid" : "low";
    return '<div class="score ' + cls + '" role="status">Ergebnis: ' + st.score + " von " + st.total + " richtig</div>";
  }

  function notesHtml(ex) {
    var items = (ex.notes || []).concat(ex.paper_notes || []);
    if (!items.length) return "";
    return '<div class="card notes"><details><summary>Anmerkungen zur Übertragung aus dem PDF</summary><ul>' +
      items.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul></details></div>";
  }

  function itemStatus(ex, st, n) {
    var a = st.answers[n], c = ex.solution[n];
    if (!st.checked && !st.revealed) return "";
    if (st.checked && a) return a === c ? "correct" : "wrong";
    if (st.revealed || st.checked) return "missed";
    return "";
  }
  function fb(ex, st, n, labelFn) {
    var c = ex.solution[n], a = st.answers[n];
    if (st.checked && a) {
      if (a === c) return '<div class="feedback ok">✓ Richtig</div>';
      return '<div class="feedback bad">✗ Falsch — richtig ist: ' + labelFn(c) + "</div>";
    }
    if (st.checked && !a) return '<div class="feedback bad">Keine Antwort — richtig ist: ' + labelFn(c) + "</div>";
    if (st.revealed) return '<div class="feedback ok">Lösung: ' + labelFn(c) + "</div>";
    return "";
  }

  function selectHtml(name, opts, value, disabled, cls) {
    return '<select class="' + (cls || "") + '" data-n="' + name + '"' + (disabled ? " disabled" : "") + ' aria-label="Antwort ' + name + '">' +
      '<option value="">–</option>' + opts.map(function (o) {
        return '<option value="' + esc(o[0]) + '"' + (value === o[0] ? " selected" : "") + ">" + esc(o[1]) + "</option>";
      }).join("") + "</select>";
  }

  function renderLesen1(ex, st) {
    var locked = st.checked || st.revealed;
    var headLabel = function (k) { var h = ex.headings.find(function (x) { return x.key === k; }); return "<b>" + U(k) + "</b>) " + esc(h ? h.text : ""); };
    var h = '<div class="card"><h2>Überschriften</h2><ul class="headings-list">' + ex.headings.map(function (x) {
      return "<li><b>" + U(x.key) + ")</b> " + esc(x.text) + "</li>"; }).join("") + "</ul></div>";
    h += '<div class="questions"><h2>Texte 1–5: Welche Überschrift passt?</h2><div class="texts-list">';
    ex.texts.forEach(function (t) {
      var n = String(t.num), s = itemStatus(ex, st, n);
      h += '<div class="t row ' + (s === "missed" ? "" : s) + '"><div class="q-num">' + t.num + '.</div><div class="reading">' + paragraphs(t.text) + "</div>" +
        "<div>" + selectHtml(n, ex.headings.map(function (x) { return [x.key, U(x.key)]; }), st.answers[n], locked) + "</div>" +
        '<div class="sol">' + fb(ex, st, n, headLabel) + "</div></div>";
    });
    return h + "</div></div>";
  }

  function renderLesen2(ex, st) {
    var locked = st.checked || st.revealed;
    var h = '<div class="card reading">' + (ex.title ? '<div class="title">' + esc(ex.title) + "</div>" : "") +
      (ex.subtitle ? '<div class="subtitle">' + esc(ex.subtitle) + "</div>" : "") + paragraphs(ex.text) + "</div>";
    h += '<div class="questions"><h2>Aufgaben 6–10</h2>';
    ex.questions.forEach(function (q) {
      var n = String(q.num), a = st.answers[n], c = ex.solution[n];
      h += '<div class="q" role="radiogroup" aria-label="Aufgabe ' + n + '"><div class="q-stem"><span class="q-num">' + n + ".</span>" + esc(q.stem) + "</div>";
      ["a", "b", "c"].forEach(function (k) {
        var cls = "";
        if (st.checked) { if (k === c) cls = a === c ? "correct" : "missed"; else if (k === a) cls = "wrong"; }
        else if (st.revealed && k === c) cls = "correct";
        h += '<label class="opt ' + cls + '"><input type="radio" name="q' + n + '" value="' + k + '" data-n="' + n + '"' +
          (a === k ? " checked" : "") + (locked ? " disabled" : "") + '><span class="letter">' + U(k) + "</span><span>" + esc(q.options[k]) + "</span></label>";
      });
      h += fb(ex, st, n, function (k) { return "<b>" + U(k) + "</b> " + esc(q.options[k]); }) + "</div>";
    });
    return h + "</div>";
  }

  function renderLesen3(ex, st) {
    var locked = st.checked || st.revealed;
    var adLabel = function (k) { return k === "x" ? "<b>X</b> (keine passende Anzeige)" : "Anzeige <b>" + U(k) + "</b>"; };
    var h = '<div class="questions"><h2>Situationen 11–20: Welche Anzeige passt?</h2><div class="match-table">';
    ex.situations.forEach(function (s) {
      var n = String(s.num), stt = itemStatus(ex, st, n);
      h += '<div class="row ' + (stt === "missed" ? "" : stt) + '"><div class="q-num">' + n + '.</div><div>' + esc(s.text) + "</div><div>" +
        selectHtml(n, ex.ads.map(function (a) { return [a.key, U(a.key)]; }).concat([["x", "X (keine)"]]), st.answers[n], locked) +
        '</div><div class="sol">' + fb(ex, st, n, adLabel) + "</div></div>";
    });
    h += "</div></div>";
    h += '<div class="card"><h2>Anzeigen a–l</h2><div class="ads-grid">' + ex.ads.map(function (a) {
      return '<div class="ad"><span class="ad-key">' + U(a.key) + "</span>\n" + markIllegible(esc(a.text)) + "</div>"; }).join("") + "</div>";
    if (ex.ads_image) {
      h += '<details class="orig-img"><summary>Originalseite (Foto aus dem PDF) anzeigen</summary><img loading="lazy" src="' + esc(ex.ads_image) +
        '" alt="Originalseite mit den Anzeigen a bis l"></details>';
    }
    return h + "</div>";
  }

  function gapText(ex, st, optsFor, labelFor) {
    var locked = st.checked || st.revealed;
    var html = paragraphs(ex.text);
    return html.replace(/\[\[(\d+)\]\]/g, function (_, n) {
      var s = itemStatus(ex, st, n), a = st.answers[n], c = ex.solution[n];
      var fix = "";
      if ((st.checked && a !== c) || (st.revealed && !st.checked)) fix = '<span class="fix" title="richtige Lösung">→ ' + esc(labelFor(c, n)) + "</span>";
      return '<span class="gap ' + (s === "missed" ? "wrong" : s) + '"><span class="gnum">(' + n + ")</span>" +
        selectHtml(n, optsFor(n), a, locked, "gap-select") + fix + "</span>";
    });
  }

  function renderSprach1(ex, st) {
    var g = {}; ex.gaps.forEach(function (x) { g[x.num] = x.options; });
    var h = '<div class="questions"><h2>Text mit Lücken 21–30</h2><div class="gap-text">' +
      gapText(ex, st, function (n) { return ["a", "b", "c"].map(function (k) { return [k, U(k) + ") " + g[n][k]]; }); },
        function (k, n) { return U(k) + ") " + g[n][k]; }) + "</div></div>";
    h += '<div class="card"><h2>Antwortmöglichkeiten</h2><table class="options-table"><tbody>' + ex.gaps.map(function (x) {
      return "<tr><th>" + x.num + "</th><td>" + ["a", "b", "c"].map(function (k) { return "<b>" + U(k) + "</b> " + esc(x.options[k]); }).join(" &nbsp;·&nbsp; ") + "</td></tr>";
    }).join("") + "</tbody></table></div>";
    return h;
  }

  function renderSprach2(ex, st) {
    var w = {}; ex.words.forEach(function (x) { w[x.key] = x.word; });
    var opts = ex.words.map(function (x) { return [x.key, U(x.key) + " – " + x.word]; });
    var used = {}; Object.keys(st.answers).forEach(function (n) { if (st.answers[n]) used[st.answers[n]] = true; });
    var h = '<div class="card"><h2>Wörter (a–o) — jedes Wort passt nur einmal</h2><div class="wordbank">' + ex.words.map(function (x) {
      return '<div class="' + (used[x.key] ? "used" : "") + '"><b>' + U(x.key) + "</b>" + esc(x.word) + "</div>"; }).join("") + "</div></div>";
    h += '<div class="questions"><h2>Text mit Lücken 31–40</h2><div class="gap-text">' +
      gapText(ex, st, function () { return opts; }, function (k) { return U(k) + " – " + w[k]; }) + "</div></div>";
    return h;
  }

  function render() {
    list = visibleList();
    if (!list.length) { $("exercise").innerHTML = "<p>Keine Übungen für diesen Filter.</p>"; renderOverview(); return; }
    if (idx >= list.length) idx = list.length - 1;
    var ex = list[idx], st = state(ex);
    var body = { lesen1: renderLesen1, lesen2: renderLesen2, lesen3: renderLesen3, sprach1: renderSprach1, sprach2: renderSprach2 }[ex.type](ex, st);
    $("exercise").innerHTML = headerHtml(ex) + scoreHtml(st) + body + notesHtml(ex);
    $("position").textContent = "Übung " + (idx + 1) + " von " + list.length;
    $("prevBtn").disabled = idx === 0;
    $("nextBtn").disabled = idx === list.length - 1;
    $("checkBtn").disabled = st.checked;
    $("solutionBtn").textContent = st.revealed ? "Lösung zeigen ✓" : "Lösung zeigen";
    $("solutionBtn").disabled = st.revealed;
    prefs.current = ex.id; save(PREF_KEY, prefs);
    if (location.hash !== "#" + ex.id) history.replaceState(null, "", "#" + ex.id);
    document.title = TYPE_LABEL[ex.type] + " · Modelltest " + ex.paper.slice(1) + " – TELC B1";
    renderOverview();
  }

  function badge(ex) {
    var st = progress[canon(ex)];
    if (!st || !st.checked || st.total == null) return st && st.revealed ? '<span class="badge">Lösung</span>' : "";
    return '<span class="badge ' + (st.score === st.total ? "done-full" : "done-part") + '">' + st.score + "/" + st.total + "</span>";
  }

  function renderOverview() {
    var html = "", lastPaper = null, done = 0;
    list.forEach(function (ex, i) {
      if (ex.paper !== lastPaper) { html += '<div class="ov-paper">Modelltest ' + ex.paper.slice(1) + "</div>"; lastPaper = ex.paper; }
      var st = progress[canon(ex)]; if (st && st.checked) done++;
      var label = SHORT[ex.type] + (ex.id.slice(-1) === "b" ? " (Variante)" : "") + (ex.topic ? " · " + ex.topic : "");
      html += '<button class="ov-item' + (i === idx ? " active" : "") + '" data-i="' + i + '"' + (i === idx ? ' aria-current="true"' : "") + '>' +
        '<span class="num">' + (i + 1) + '</span><span class="lbl">' + esc(label) + "</span>" + badge(ex) + "</button>";
    });
    $("ovList").innerHTML = html;
    $("ovStats").textContent = done + " von " + list.length + " Übungen bearbeitet";
    var act = $("ovList").querySelector(".active");
    if (act && act.scrollIntoView && !overviewScrolled) { act.scrollIntoView({ block: "nearest" }); }
  }
  var overviewScrolled = false;

  // ---------- actions ----------
  function current() { return list[idx]; }
  function check() {
    var ex = current(), st = state(ex), n = nums(ex), score = 0;
    n.forEach(function (k) { if (st.answers[k] === ex.solution[k]) score++; });
    st.checked = true; st.score = score; st.total = n.length; persist(); render();
    var s = document.querySelector(".score"); if (s && s.scrollIntoView) s.scrollIntoView({ block: "center", behavior: "smooth" });
  }
  function reveal() { var st = state(current()); st.revealed = true; persist(); render(); }
  function resetEx() { var ex = current(); progress[canon(ex)] = { answers: {}, checked: false, revealed: false, score: null, total: null }; persist(); render(); }
  function go(d) { var n = idx + d; if (n < 0 || n >= list.length) return; idx = n; render(); $("main").focus(); window.scrollTo(0, 0); }

  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.closest && t.closest("#exercise") && t.getAttribute("data-n")) {
      var st = state(current()); if (st.checked || st.revealed) return;
      st.answers[t.getAttribute("data-n")] = t.value || undefined;
      if (!t.value) delete st.answers[t.getAttribute("data-n")];
      persist();
      if (current().type === "sprach2") {
        var used = {}; Object.keys(st.answers).forEach(function (k) { used[st.answers[k]] = true; });
        Array.prototype.forEach.call(document.querySelectorAll(".wordbank div"), function (d) {
          var key = d.querySelector("b").textContent.toLowerCase(); d.classList.toggle("used", !!used[key]);
        });
      }
    }
  });
  $("prevBtn").onclick = function () { go(-1); };
  $("nextBtn").onclick = function () { go(1); };
  $("checkBtn").onclick = check;
  $("solutionBtn").onclick = reveal;
  $("resetBtn").onclick = resetEx;
  $("ovList").onclick = function (e) {
    var b = e.target.closest(".ov-item"); if (!b) return;
    idx = Number(b.getAttribute("data-i")); overviewScrolled = true; render(); overviewScrolled = false;
    $("overview").classList.remove("open"); window.scrollTo(0, 0);
  };
  $("menuBtn").onclick = function () { $("overview").classList.toggle("open"); };
  $("closeOverview").onclick = function () { $("overview").classList.remove("open"); };
  $("showDupes").checked = !!prefs.showDupes;
  $("typeFilter").value = prefs.type || "all";
  $("showDupes").onchange = function () { var id = current() && current().id; prefs.showDupes = this.checked; save(PREF_KEY, prefs); list = visibleList(); setIndexById(id); render(); };
  $("typeFilter").onchange = function () { var id = current() && current().id; prefs.type = this.value; save(PREF_KEY, prefs); list = visibleList(); setIndexById(id); render(); };
  $("resetAll").onclick = function () {
    if (confirm("Gesamten Fortschritt (alle Antworten und Ergebnisse) löschen?")) { progress = {}; persist(); render(); }
  };
  document.addEventListener("keydown", function (e) {
    if (e.target && /^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)) return;
    if (e.key === "ArrowRight") go(1);
    if (e.key === "ArrowLeft") go(-1);
  });
  window.addEventListener("hashchange", function () { setIndexById(location.hash.slice(1)); render(); });

  // ---------- start ----------
  if (!ALL.length) { $("exercise").innerHTML = "<p>Die Übungsdaten (data/exercises.js) konnten nicht geladen werden.</p>"; return; }
  setIndexById(location.hash ? location.hash.slice(1) : prefs.current);
  render();
})();
