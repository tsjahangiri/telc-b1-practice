# TELC B1 practice website (Lesen & Sprachbausteine)

Built from `B1-telc past papers(1).pdf` (493 pages, 30 exam papers). Works fully offline — no server, database or internet needed.

## How to start
Double-click **`website/index.html`** (opens in your browser). That's it.

Optional (if your browser restricts local files): in a terminal run
```
cd website && python3 -m http.server 8000
```
and open http://localhost:8000.

## Using it
- 65 distinct exercises in PDF order (148 if you tick "Doppelte Übungen anzeigen" — the PDF repeats many papers).
- Overview on the left (☰ on mobile), filter by part, Weiter/Zurück (or ← → keys).
- Antworten prüfen → green/red feedback + correct answer; Lösung zeigen; Zurücksetzen.
- Progress is saved in your browser (localStorage). Answer keys come only from the PDF's Lösungen pages.
- For Lesen 3, "Originalseite anzeigen" shows the photographed ad page from the PDF.

## Files
- `website/` — the site (`data/exercises.js` is generated; `img/` = original ad pages)
- `extraction/extracted_content.json` — all structured exercises + text of every page
- `extraction/verification_report.md`, `extraction/uncertain_content.md`, `extraction/extraction_log.md`
- `extraction/papers/PNN.json` (+ `.dump.txt`), `extraction/batches/` (50 batch files + reports)
- `extraction/corrections/` — every manual correction/transcription, auditable
- `progress.md` — status; `tools/` — scripts to rebuild (`build_paper.py`, `audit.py`, `export_web.py`)
- `source/original.pdf` — unmodified copy of the PDF
