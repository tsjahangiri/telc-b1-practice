# Progress — TELC B1 practice website

**Current phase:** Second-pass audit complete (see audit/final_audit_report.md)

- Source: `source/original.pdf` (unmodified copy of `B1-telc past papers(1).pdf`) — **493 pages**
- Structure: 30 exam papers (P01–P30) + speaking-exam notes — see `extraction/document_map.md`
- Pages extracted: **493/493** (1–493)
- Pages visually verified: **493/493** (1–493)
- Pages whose text comes from OCR (image-only pages): 6, 17, 28, 36, 37, 41, 54, 67, 80, 95, 109, 122, 135, 148, 161, 176, 189, 228, 242, 258, 276, 290, 307, 318, 336, 356, 357, 361, 374, 387, 402, 417, 432, 447
- Uncertain items recorded: 19 (see `extraction/uncertain_content.md`)

## Batches (10 pages each)
| Batch | Pages | Extracted | Visually verified | OCR pages | Status |
|---|---|---|---|---|---|
| 01 | 1–10 | 10/10 | 10/10 | 6 | complete |
| 02 | 11–20 | 10/10 | 10/10 | 17 | complete |
| 03 | 21–30 | 10/10 | 10/10 | 28 | complete |
| 04 | 31–40 | 10/10 | 10/10 | 36, 37 | complete |
| 05 | 41–50 | 10/10 | 10/10 | 41 | complete |
| 06 | 51–60 | 10/10 | 10/10 | 54 | complete |
| 07 | 61–70 | 10/10 | 10/10 | 67 | complete |
| 08 | 71–80 | 10/10 | 10/10 | 80 | complete |
| 09 | 81–90 | 10/10 | 10/10 | – | complete |
| 10 | 91–100 | 10/10 | 10/10 | 95 | complete |
| 11 | 101–110 | 10/10 | 10/10 | 109 | complete |
| 12 | 111–120 | 10/10 | 10/10 | – | complete |
| 13 | 121–130 | 10/10 | 10/10 | 122 | complete |
| 14 | 131–140 | 10/10 | 10/10 | 135 | complete |
| 15 | 141–150 | 10/10 | 10/10 | 148 | complete |
| 16 | 151–160 | 10/10 | 10/10 | – | complete |
| 17 | 161–170 | 10/10 | 10/10 | 161 | complete |
| 18 | 171–180 | 10/10 | 10/10 | 176 | complete |
| 19 | 181–190 | 10/10 | 10/10 | 189 | complete |
| 20 | 191–200 | 10/10 | 10/10 | – | complete |
| 21 | 201–210 | 10/10 | 10/10 | – | complete |
| 22 | 211–220 | 10/10 | 10/10 | – | complete |
| 23 | 221–230 | 10/10 | 10/10 | 228 | complete |
| 24 | 231–240 | 10/10 | 10/10 | – | complete |
| 25 | 241–250 | 10/10 | 10/10 | 242 | complete |
| 26 | 251–260 | 10/10 | 10/10 | 258 | complete |
| 27 | 261–270 | 10/10 | 10/10 | – | complete |
| 28 | 271–280 | 10/10 | 10/10 | 276 | complete |
| 29 | 281–290 | 10/10 | 10/10 | 290 | complete |
| 30 | 291–300 | 10/10 | 10/10 | – | complete |
| 31 | 301–310 | 10/10 | 10/10 | 307 | complete |
| 32 | 311–320 | 10/10 | 10/10 | 318 | complete |
| 33 | 321–330 | 10/10 | 10/10 | – | complete |
| 34 | 331–340 | 10/10 | 10/10 | 336 | complete |
| 35 | 341–350 | 10/10 | 10/10 | – | complete |
| 36 | 351–360 | 10/10 | 10/10 | 356, 357 | complete |
| 37 | 361–370 | 10/10 | 10/10 | 361 | complete |
| 38 | 371–380 | 10/10 | 10/10 | 374 | complete |
| 39 | 381–390 | 10/10 | 10/10 | 387 | complete |
| 40 | 391–400 | 10/10 | 10/10 | – | complete |
| 41 | 401–410 | 10/10 | 10/10 | 402 | complete |
| 42 | 411–420 | 10/10 | 10/10 | 417 | complete |
| 43 | 421–430 | 10/10 | 10/10 | – | complete |
| 44 | 431–440 | 10/10 | 10/10 | 432 | complete |
| 45 | 441–450 | 10/10 | 10/10 | 447 | complete |
| 46 | 451–460 | 10/10 | 10/10 | – | complete |
| 47 | 461–470 | 10/10 | 10/10 | – | complete |
| 48 | 471–480 | 10/10 | 10/10 | – | complete |
| 49 | 481–490 | 10/10 | 10/10 | – | complete |
| 50 | 491–493 | 3/3 | 3/3 | – | complete |

## Structured papers (Lesen + Sprachbausteine)
| Paper | Pages | Exercises | Verified | Missing sections |
|---|---|---|---|---|
| P01 | 1–13 | 5 | 5 | – |
| P02 | 14–22 | 3 | 3 | L2, SB1 |
| P03 | 23–35 | 5 | 5 | – |
| P04 | 36–48 | 5 | 5 | – |
| P05 | 49–61 | 5 | 5 | – |
| P06 | 62–74 | 5 | 5 | – |
| P07 | 75–88 | 5 | 5 | – |
| P08 | 89–103 | 6 | 6 | – |
| P09 | 104–116 | 5 | 5 | – |
| P10 | 117–129 | 5 | 5 | – |
| P11 | 130–142 | 5 | 5 | – |
| P12 | 143–155 | 5 | 5 | – |
| P13 | 156–168 | 5 | 5 | – |
| P14 | 171–183 | 5 | 5 | – |
| P15 | 184–197 | 5 | 5 | – |
| P16 | 223–235 | 5 | 5 | – |
| P17 | 236–250 | 6 | 6 | – |
| P18 | 253–265 | 5 | 5 | – |
| P19 | 271–284 | 5 | 5 | – |
| P20 | 285–298 | 5 | 5 | – |
| P21 | 304–312 | 3 | 3 | L2, SB1 |
| P22 | 313–325 | 5 | 5 | – |
| P23 | 331–343 | 5 | 5 | – |
| P24 | 356–368 | 5 | 5 | – |
| P25 | 369–381 | 5 | 5 | – |
| P26 | 382–394 | 5 | 5 | – |
| P27 | 397–409 | 5 | 5 | – |
| P28 | 412–424 | 5 | 5 | – |
| P29 | 427–439 | 5 | 5 | – |
| P30 | 442–454 | 5 | 5 | – |

## Notes
Second-pass audit 2026-11-10: 0 content/key errors found; ads rebuilt; P06/P30 ads a–c reconstructed with markers; 148/148 regression tests pass.
