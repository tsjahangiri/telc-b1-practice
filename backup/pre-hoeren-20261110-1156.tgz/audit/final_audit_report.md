# Final audit report — second pass (2026-11-10)

Source of truth: `source/original.pdf` (unmodified copy of `B1-telc past papers(1).pdf`). Backup taken before changes: `backup/pre-audit-20261110-0728.tgz`.

## 1–9 Figures
| Item | Result |
|---|---|
| 1. PDF pages reviewed | 493 / 493 (50 batches of 10 — `page_comparison.md`) |
| 2. Exercises audited | 148 (all papers incl. duplicates; 65 distinct) |
| 3. Reading exercises (Lesen) | 90 (L1: 30, L2: 30 incl. 2 variant sets, L3: 30) |
| 4. Sprachbausteine exercises | 58 (Teil 1: 28 — P02/P21 have none in the PDF; Teil 2: 30) |
| 5. Questions / items checked | 1180 (515 distinct) |
| 6. Answers verified against Lösungen | 1180 / 1180 (two independent readings of the key pages + 570 answer words matched to option text) |
| 7. Errors discovered | 0 in texts, questions, options, numbering, ordering or keys. 6 presentation/website defects (uppercase transform altering capitalisation, price mis-styling, ragged ad text on phones, hyphen joining, 3-px mobile overflow, cache) — all fixed |
| 8. Corrections made | 7 (see `corrections_log.md`): 1 content (marked reconstruction of blurred ads), 6 website |
| 9. Advertisements recreated | 144 distinct ads on 12 ad pages (30 Lesen-3 exercises) rebuilt as newspaper-style layouts with real text |

## Method (summary)
- **Text audit:** every exercise compared word-by-word with an independent OCR reading of the page images (`tools/crosscheck.py`, `tools/seqcheck.py`); every flagged word/run reviewed against the page image. All flags were OCR noise (watermark, umlauts, table/photo reading order) or confirmed correct (e.g. 'GUTE', 'Chiffre 2063/9369', P08 options).
- **Key audit:** `tools/keycheck.py` → `answer_key_verification.md` (1180 rows). Entries in a different font were confirmed visually; the P08/P17 modified question set uses the green key column (documented).
- **Ad audit/rebuild:** `image_audit.md`. Automated browser check: on-screen text of every rendered ad = verified transcription (0 mismatches).
- **Regression test** (automated in the browser, all 148 exercises, desktop + 375-px mobile): open, enter official answers → full score; enter wrong answers → 0 and every item marked wrong; Lösung zeigen shows every answer; Zurücksetzen clears; progress persists after reload; Weiter/Zurück and counter correct (1…148, Zurück disabled on first); 30 ad images load; no horizontal overflow; no JavaScript errors. German characters render correctly.
- **Offline:** no external resources are loaded (fonts, scripts, images all local; data is a local `.js` file, so the site also works by double-clicking `index.html`).

## 10. Unresolved uncertainties
- P06/P30 ads a–c: reconstructed text (19 marked segments) — plausible but not verifiable; names/prices/digits remain `[unleserlich]` (29 illegible markers across ad pages, mainly P06 ads i, j, l cut off at the photo edge).
- Low-confidence small print in some ads (phone numbers, names) — listed in `extraction/uncertain_content.md`.
- Source defects kept as printed (missing words P02/P21 L1 texts 2–5; missing line after gap 27 in P04/P24 SB1; misspellings in word banks).
- P08/P17 L2 variant key: association with the green key column is inferred from consistency.
- Not tested by me: opening `index.html` directly from disk in your own browser (the test pane only serves pages over HTTP). The page uses only relative `<script>`/`<link>` tags, so it is expected to work.

## 11. Final website testing results
148/148 exercises pass all functional checks on desktop and mobile; 0 console errors; 0 ad-text mismatches; 0 overflow.
